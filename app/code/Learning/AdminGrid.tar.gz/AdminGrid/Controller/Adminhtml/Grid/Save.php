<?php

namespace Learning\AdminGrid\Controller\Adminhtml\Grid;

use Exception;
use Learning\AdminGrid\Model\AdminGridFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use RuntimeException;

class Save extends Action
{
    /**
     * @var Session
     */
    protected $_adminSession;

    /**
     * @var AdminGridFactory
     */
    protected $adminGridFactory;

    public function __construct(
        Context $context,
        Session $adminSession,
        AdminGridFactory $adminGridFactory
    ) {
        parent::__construct($context);
        $this->_adminSession = $adminSession;
        $this->adminGridFactory = $adminGridFactory;
    }

    /**
     * @return ResponseInterface|ResultInterface|void
     */
    public function execute()
    {
        $postObj = $this->getRequest()->getPostValue();
        $name = $postObj["name"];
        $date = date("Y-m-d");
        $username = $this->_adminSession->getUser()->getFirstName();
        if ($username == $name) {
            $username = $this->_adminSession->getUser()->getFirstName();
        } else {
            $username = $name;
        }

        $userDetail = ["name" => $username, "created_at" => $date];
        $data = array_merge($postObj, $userDetail);
        $resultRedirect = $this->resultRedirectFactory->create();

        if ($data) {
            $model = $this->adminGridFactory->create();
            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
            $model->setData($data);

            try {
                $model->save();
                $this->messageManager->addSuccess(__('The data has been saved'));
                $this->_adminSession->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath(
                        'adminhtml/*/edit',
                        ['id' => $model->getId(), '_current' => true]
                    );
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the data.'));
            }
            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}
