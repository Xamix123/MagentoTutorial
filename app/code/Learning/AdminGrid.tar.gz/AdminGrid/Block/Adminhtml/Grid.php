<?php

namespace Learning\AdminGrid\Block\Adminhtml;

use Magento\Backend\Block\Widget\Container;
use Magento\Backend\Block\Widget\Context;

class Grid extends Container
{
    /**
     * @var string
     */
    protected $_template = 'grid/view.phtml';

    public function __construct(
        Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);
    }

    /**
     * {@inheritdoc}
     */
    protected function _prepareLayout()
    {
        //add Button
        $addButtonProps = [
            'id' =>  'add_new_grid',
            'label' => __('Add New'), //add Button text
            'class' => 'add', // add button class
            'button_class' => '',
            'class_name' => 'Magento\Backend\Block\Widget\Button',
            'onclick' => "setLocation('" . $this->_getCreateUrl() . "')"
//            'options' => $this->_getAddButtonOptions() // data option
        ];
        $this->buttonList->add('add_new', $addButtonProps); // add new button with id add_new
        $this->setChild('grid', $this->getLayout()->createBlock(
            'Learning\AdminGrid\Block\Adminhtml\Grid\Grid',
            'grid.view.grid'
        )); //set child to the grid block which we create here with type('Learning\AdminGrid\Block\Adminhtml\Grid\Grid') and name 'grid.view.grid'
        return parent::_prepareLayout();
    }

//    /**
//     * @return array
//     */
//    protected function _getAddButtonOptions()
//    {
//        $splitButtonOptions[] = [
//            'label' => __('Add New'),
//            'onclick' => "setLocation('" . $this->_getCreateUrl() . "')",
//        ];
//        return $splitButtonOptions;
//    }

    /**
     * @return string
     */
    protected function _getCreateUrl()
    {
        return $this->getUrl('admingrid/*/new'); // get create url
    }

    /**
     * @return string
     */
    public function getGridHtml()
    {
        return $this->getChildHtml('grid'); // get grid html
    }
}
