<?php

namespace Learning\AdminGrid\Block\Adminhtml\Grid;

use Magento\Backend\Block\Widget\Context;
use Magento\Backend\Block\Widget\Form\Container;
use Magento\Framework\Phrase;
use Magento\Framework\Registry;

class Edit extends Container
{
    /**
     * @var Registry
     */
    protected $_coreRegistry = null;

    /**
     * Edit constructor.
     * @param Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        array $data = []
    ) {
        $this->_coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    protected function _construct()
    {
        $this->_objectId = 'id';
        $this->_blockGroup = 'learning_adminGrid';

        $this->_controller = 'adminhtml_grid';
        parent::_construct();
        $this->buttonList->update('save', 'label', __('Save Grid'));

        $this->buttonList->update('delete', 'label', __('Delete'));
    }

    /**
     * @return Phrase|string
     */
    public function getHeaderText()
    {
        if ($this->_coreRegistry->registry('learning_adminGrid_form_data')->getId()) {
            return __("Edit Record '%1'", $this->escapeHtml($this->_coreRegistry->registry('learning_adminGrid_form_data')->getTitle()));
        } else {
            return __('New Record');
        }
    }

    /**
     * Retrieve the save and continue edit Url
     *
     * @return string
     */
    public function _getSaveAndContinueUrl()
    {
        return $this->getUrl(
            'admingrid/*/save',
            ['_current' => true, 'back' => 'edit', 'active_tab' => '{{tab_id}}']
        );
    }

    /**
     * Prepare the layout.
     *
     * @return $this
     */
    protected function _prepareLayout()
    {
        $this->_formScripts[] = "
        function toggleEditor() {
            if (tinyMCE.getInstanceById('page_content') == null) {
                tinyMCE.execCommand('mceAddControl', false, 'content');
            } else {
                tinyMCE.execCommand('mceRemoveControl', false, 'content');
            }
        };
        ";
        return parent::_prepareLayout();
    }
}
