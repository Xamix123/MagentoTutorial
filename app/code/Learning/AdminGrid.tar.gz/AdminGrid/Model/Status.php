<?php

namespace Learning\AdminGrid\Model;

class Status implements \Magento\Framework\Option\ArrayInterface
{
    // __ function for translate
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 2;

    public function toOptionArray()
    {
        return [
            self::STATUS_ENABLED => __('Enabled'),
            self::STATUS_DISABLED => __('Disabled')
        ];
    }

    public function getOptionArray()
    {
        return [
            self::STATUS_ENABLED => __('Enabled'),
            self::STATUS_DISABLED => __('Disabled')
        ];
    }
}
