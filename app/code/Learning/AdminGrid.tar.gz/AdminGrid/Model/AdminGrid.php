<?php

namespace Learning\AdminGrid\Model;

use Magento\Framework\Model\AbstractModel;
use Learning\AdminGrid\Model\ResourceModel\AdminGrid as ResourceModel;

class AdminGrid extends AbstractModel
{
    public function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}
