<?php

namespace Learning\CarTutorial\Block;

class GrandSonBlock extends ChildBlock
{

    public function showBlockName()
    {
        echo "====>i am in GrandSonBlock";
    }
}
