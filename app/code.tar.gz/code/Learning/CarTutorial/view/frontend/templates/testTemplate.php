<?php
use Learning\CarTutorial\Block\ChildBlock;
/** @var ChildBlock $block */
$block->showBlockName();
?>

    <p><?= 'I AM IN OVERRIDE THEME' ?></p>
<?php
