<?php

namespace Learning\CarTutorialOld\Controller\User;

use Magento\Framework\App\Action\Action;

class View extends Action
{
    public function execute()
    {
        echo " i am in User dir";
    }
}
